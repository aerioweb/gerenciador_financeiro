const express = require('express');
const router = express.Router();
const UserModel = require('../models/user');

// Dependendo de como o db é exportado em app.js
const { db } = require('../app');
const userModel = new UserModel(db);

// GET: tela de login
router.get('/login', (req, res) => {
  res.render('login', { error: null });
});

// POST: autenticação de login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await userModel.authenticate(email, password);
    if (!user) {
      return res.render('login', { error: 'Usuário ou senha inválidos.' });
    }
    req.session.userId = user.id;
    res.redirect('/dashboard');
  } catch (err) {
    res.render('login', { error: 'Erro no login.' });
  }
});

// GET: tela de registro
router.get('/register', (req, res) => {
  res.render('register', { error: null });
});

// POST: registro de novo usuário
router.post('/register', async (req, res) => {
  const { name, email, password, confirm_password } = req.body;
  if (password !== confirm_password) {
    return res.render('register', { error: 'As senhas não coincidem.' });
  }
  try {
    const existing = await userModel.findByEmail(email);
    if (existing) {
      return res.render('register', { error: 'E-mail já cadastrado.' });
    }
    await userModel.create({ name, email, password });
    res.redirect('/login');
  } catch (err) {
    res.render('register', { error: 'Erro ao registrar usuário.' });
  }
});

// GET: logout
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

module.exports = router;