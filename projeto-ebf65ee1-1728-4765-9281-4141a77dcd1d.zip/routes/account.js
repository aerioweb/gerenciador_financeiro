const express = require('express');
const router = express.Router();
const AccountModel = require('../models/account');
const CompanyModel = require('../models/company');
const { requireAuth } = require('../middlewares/auth');
const { db } = require('../app');
const accountModel = new AccountModel(db);
const companyModel = new CompanyModel(db);

// Listar contas da empresa ativa
router.get('/accounts', requireAuth, async (req, res) => {
  const activeCompanyId = req.session.activeCompanyId;
  if (!activeCompanyId) {
    // Redireciona para o dashboard se a empresa não estiver selecionada
    return res.redirect('/dashboard');
  }
  try {
    const accounts = await accountModel.findByCompany(activeCompanyId);
    res.render('accounts', { accounts, error: null });
  } catch (err) {
    res.render('accounts', { accounts: [], error: 'Erro ao buscar contas.' });
  }
});

// Formulário para nova conta
router.get('/accounts/new', requireAuth, (req, res) => {
  if (!req.session.activeCompanyId) {
    return res.redirect('/dashboard');
  }
  res.render('account_new', { error: null });
});

// Criar nova conta
router.post('/accounts/new', requireAuth, async (req, res) => {
  const activeCompanyId = req.session.activeCompanyId;
  const { name, initial_balance } = req.body;
  if (!activeCompanyId) {
    return res.redirect('/dashboard');
  }
  if (!name) {
    return res.render('account_new', { error: 'Nome da conta é obrigatório.' });
  }
  try {
    await accountModel.create({
      company_id: activeCompanyId,
      name,
      initial_balance: parseFloat(initial_balance) || 0
    });
    res.redirect('/accounts');
  } catch (err) {
    res.render('account_new', { error: 'Erro ao criar conta.' });
  }
});

module.exports = router;