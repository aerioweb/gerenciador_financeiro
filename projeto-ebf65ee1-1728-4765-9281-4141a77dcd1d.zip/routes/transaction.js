const express = require('express');
const router = express.Router();
const TransactionModel = require('../models/transaction');
const AccountModel = require('../models/account');
const CategoryModel = require('../models/category');
const { requireAuth } = require('../middlewares/auth');
const { db } = require('../app');

const transactionModel = new TransactionModel(db);
const accountModel = new AccountModel(db);
const categoryModel = new CategoryModel(db);

// Listar lançamentos da empresa ativa
router.get('/transactions', requireAuth, async (req, res) => {
  const activeCompanyId = req.session.activeCompanyId;
  if (!activeCompanyId) {
    return res.redirect('/dashboard');
  }
  try {
    const transactions = await transactionModel.findByCompany({ company_id: activeCompanyId });
    res.render('transactions', { transactions, error: null });
  } catch (err) {
    res.render('transactions', { transactions: [], error: 'Erro ao buscar lançamentos.' });
  }
});

// Formulário para novo lançamento
router.get('/transactions/new', requireAuth, async (req, res) => {
  const activeCompanyId = req.session.activeCompanyId;
  if (!activeCompanyId) {
    return res.redirect('/dashboard');
  }
  try {
    const accounts = await accountModel.findByCompany(activeCompanyId);
    const categories = await categoryModel.findByCompany(activeCompanyId);
    res.render('transaction_new', { error: null, accounts, categories });
  } catch (err) {
    res.render('transaction_new', { error: 'Erro ao carregar dados.', accounts: [], categories: [] });
  }
});

// Criar novo lançamento
router.post('/transactions/new', requireAuth, async (req, res) => {
  const activeCompanyId = req.session.activeCompanyId;
  const { account_id, category_id, type, value, description, date } = req.body;
  if (!activeCompanyId) {
    return res.redirect('/dashboard');
  }
  if (!account_id || !category_id || !type || !value || !date) {
    const accounts = await accountModel.findByCompany(activeCompanyId);
    const categories = await categoryModel.findByCompany(activeCompanyId);
    return res.render('transaction_new', { error: 'Todos os campos são obrigatórios.', accounts, categories });
  }
  if (!['receita', 'despesa'].includes(type)) {
    const accounts = await accountModel.findByCompany(activeCompanyId);
    const categories = await categoryModel.findByCompany(activeCompanyId);
    return res.render('transaction_new', { error: 'Tipo inválido.', accounts, categories });
  }
  try {
    await transactionModel.create({
      company_id: activeCompanyId,
      account_id: parseInt(account_id),
      category_id: parseInt(category_id),
      type,
      value: parseFloat(value),
      description,
      date
    });
    res.redirect('/transactions');
  } catch (err) {
    const accounts = await accountModel.findByCompany(activeCompanyId);
    const categories = await categoryModel.findByCompany(activeCompanyId);
    res.render('transaction_new', { error: 'Erro ao criar lançamento.', accounts, categories });
  }
});

module.exports = router;