const express = require('express');
const router = express.Router();
const CategoryModel = require('../models/category');
const { requireAuth } = require('../middlewares/auth');
const { db } = require('../app');
const categoryModel = new CategoryModel(db);

// Listar categorias da empresa ativa
router.get('/categories', requireAuth, async (req, res) => {
  const activeCompanyId = req.session.activeCompanyId;
  if (!activeCompanyId) {
    return res.redirect('/dashboard');
  }
  try {
    const categories = await categoryModel.findByCompany(activeCompanyId);
    res.render('categories', { categories, error: null });
  } catch (err) {
    res.render('categories', { categories: [], error: 'Erro ao buscar categorias.' });
  }
});

// Formulário para nova categoria
router.get('/categories/new', requireAuth, (req, res) => {
  if (!req.session.activeCompanyId) {
    return res.redirect('/dashboard');
  }
  res.render('category_new', { error: null });
});

// Criar nova categoria
router.post('/categories/new', requireAuth, async (req, res) => {
  const activeCompanyId = req.session.activeCompanyId;
  const { name, type } = req.body;
  if (!activeCompanyId) {
    return res.redirect('/dashboard');
  }
  if (!name || !type) {
    return res.render('category_new', { error: 'Nome e tipo são obrigatórios.' });
  }
  if (!['receita', 'despesa'].includes(type)) {
    return res.render('category_new', { error: 'Tipo inválido.' });
  }
  try {
    await categoryModel.create({
      company_id: activeCompanyId,
      name,
      type
    });
    res.redirect('/categories');
  } catch (err) {
    res.render('category_new', { error: 'Erro ao criar categoria.' });
  }
});

module.exports = router;