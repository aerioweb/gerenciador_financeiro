const express = require('express');
const router = express.Router();
const CompanyModel = require('../models/company');
const { requireAuth } = require('../middlewares/auth');
const { db } = require('../app');
const companyModel = new CompanyModel(db);

// Listar empresas do usuário
router.get('/companies', requireAuth, async (req, res) => {
  try {
    const companies = await companyModel.findByUser(req.session.userId);
    res.render('companies', { companies, error: null });
  } catch (err) {
    res.render('companies', { companies: [], error: 'Erro ao buscar empresas.' });
  }
});

// Formulário para nova empresa
router.get('/companies/new', requireAuth, (req, res) => {
  res.render('company_new', { error: null });
});

// Criar nova empresa e associar ao usuário
router.post('/companies/new', requireAuth, async (req, res) => {
  const { name } = req.body;
  if (!name) {
    return res.render('company_new', { error: 'Nome da empresa é obrigatório.' });
  }
  try {
    await companyModel.create({ name, user_id: req.session.userId });
    res.redirect('/companies');
  } catch (err) {
    res.render('company_new', { error: 'Erro ao criar empresa.' });
  }
});

// Trocar empresa ativa no dashboard
router.post('/dashboard/empresa', requireAuth, async (req, res) => {
  const { company_id } = req.body;
  // Valida se o usuário realmente tem acesso à empresa
  const companies = await companyModel.findByUser(req.session.userId);
  const found = companies.find(c => c.id == company_id);
  if (found) {
    req.session.activeCompanyId = parseInt(company_id);
  }
  res.redirect('/dashboard');
});

module.exports = router;