const express = require('express');
const router = express.Router();
const TransactionModel = require('../models/transaction');
const { requireAuth } = require('../middlewares/auth');
const { db } = require('../app');

const transactionModel = new TransactionModel(db);

// Relatório de balanço/fluxo de caixa
router.get('/reports', requireAuth, async (req, res) => {
  const activeCompanyId = req.session.activeCompanyId;
  if (!activeCompanyId) {
    return res.redirect('/dashboard');
  }
  // Filtros de período
  const { from, to } = req.query;
  try {
    const transactions = await transactionModel.findByCompany({
      company_id: activeCompanyId,
      from,
      to
    });
    let receita = 0;
    let despesa = 0;
    transactions.forEach(tx => {
      if (tx.type === 'receita') receita += tx.value;
      else if (tx.type === 'despesa') despesa += tx.value;
    });
    const saldo = receita - despesa;
    res.render('reports', {
      transactions,
      receita,
      despesa,
      saldo,
      from,
      to,
      error: null
    });
  } catch (err) {
    res.render('reports', {
      transactions: [],
      receita: 0,
      despesa: 0,
      saldo: 0,
      from,
      to,
      error: 'Erro ao gerar relatório.'
    });
  }
});

module.exports = router;