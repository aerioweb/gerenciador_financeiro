class CategoryModel {
  constructor(db) {
    this.db = db;
  }

  // Cria a tabela de categorias financeiras
  init() {
    const sql = `
      CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('receita', 'despesa')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
      )
    `;
    this.db.run(sql);
  }

  // Cria uma nova categoria para a empresa
  create({ company_id, name, type }) {
    return new Promise((resolve, reject) => {
      const sql = 'INSERT INTO categories (company_id, name, type) VALUES (?, ?, ?)';
      this.db.run(sql, [company_id, name, type], function(err) {
        if (err) return reject(err);
        resolve({ id: this.lastID, company_id, name, type });
      });
    });
  }

  // Busca todas as categorias de uma empresa
  findByCompany(company_id) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM categories WHERE company_id = ?';
      this.db.all(sql, [company_id], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }
}

module.exports = CategoryModel;