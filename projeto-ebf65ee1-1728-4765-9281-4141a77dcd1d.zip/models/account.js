class AccountModel {
  constructor(db) {
    this.db = db;
  }

  // Cria a tabela de contas financeiras
  init() {
    const sql = `
      CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        initial_balance REAL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
      )
    `;
    this.db.run(sql);
  }

  // Cria uma nova conta para a empresa
  create({ company_id, name, initial_balance = 0 }) {
    return new Promise((resolve, reject) => {
      const sql = 'INSERT INTO accounts (company_id, name, initial_balance) VALUES (?, ?, ?)';
      this.db.run(sql, [company_id, name, initial_balance], function(err) {
        if (err) return reject(err);
        resolve({ id: this.lastID, company_id, name, initial_balance });
      });
    });
  }

  // Busca todas as contas de uma empresa
  findByCompany(company_id) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM accounts WHERE company_id = ?';
      this.db.all(sql, [company_id], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }
}

module.exports = AccountModel;