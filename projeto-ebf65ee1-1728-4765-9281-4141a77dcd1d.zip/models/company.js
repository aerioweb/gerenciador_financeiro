class CompanyModel {
  constructor(db) {
    this.db = db;
  }

  // Cria as tabelas de empresas e associação usuário-empresa
  init() {
    const sqlCompany = `
      CREATE TABLE IF NOT EXISTS companies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;
    const sqlUserCompany = `
      CREATE TABLE IF NOT EXISTS user_company (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        company_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, company_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
      )
    `;
    this.db.run(sqlCompany);
    this.db.run(sqlUserCompany);
  }

  // Cria uma nova empresa e associa ao usuário
  create({ name, user_id }) {
    return new Promise((resolve, reject) => {
      const sql = 'INSERT INTO companies (name) VALUES (?)';
      this.db.run(sql, [name], function(err) {
        if (err) return reject(err);
        const companyId = this.lastID;
        // Associar o usuário à empresa criada
        const sqlAssoc = 'INSERT INTO user_company (user_id, company_id) VALUES (?, ?)';
        this.db.run(sqlAssoc, [user_id, companyId], function(err2) {
          if (err2) return reject(err2);
          resolve({ id: companyId, name });
        });
      });
    });
  }

  // Associa um usuário a uma empresa existente
  associateUser({ user_id, company_id }) {
    return new Promise((resolve, reject) => {
      const sql = 'INSERT OR IGNORE INTO user_company (user_id, company_id) VALUES (?, ?)';
      this.db.run(sql, [user_id, company_id], function(err) {
        if (err) return reject(err);
        resolve(true);
      });
    });
  }

  // Busca todas as empresas de um usuário
  findByUser(user_id) {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT c.id, c.name, c.created_at
        FROM companies c
        JOIN user_company uc ON c.id = uc.company_id
        WHERE uc.user_id = ?
      `;
      this.db.all(sql, [user_id], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }

  // Busca empresa por id
  findById(id) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM companies WHERE id = ?';
      this.db.get(sql, [id], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  }
}

module.exports = CompanyModel;