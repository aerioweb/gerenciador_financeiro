const bcrypt = require('bcrypt');

class UserModel {
  constructor(db) {
    this.db = db;
  }

  // Cria a tabela de usuários se não existir
  init() {
    const sql = `
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;
    return this.db.run(sql);
  }

  // Cria um novo usuário com senha criptografada
  async create({ name, email, password }) {
    const hash = await bcrypt.hash(password, 10);
    return new Promise((resolve, reject) => {
      const sql = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
      this.db.run(sql, [name, email, hash], function(err) {
        if (err) return reject(err);
        resolve({ id: this.lastID, name, email });
      });
    });
  }

  // Busca usuário por email
  findByEmail(email) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM users WHERE email = ?';
      this.db.get(sql, [email], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  }

  // Busca usuário por ID
  findById(id) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM users WHERE id = ?';
      this.db.get(sql, [id], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  }

  // Autentica usuário (email + senha)
  async authenticate(email, password) {
    const user = await this.findByEmail(email);
    if (!user) return null;
    const match = await bcrypt.compare(password, user.password);
    if (!match) return null;
    return user;
  }
}

module.exports = UserModel;