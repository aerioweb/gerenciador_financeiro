class TransactionModel {
  constructor(db) {
    this.db = db;
  }

  // Cria a tabela de lançamentos financeiros
  init() {
    const sql = `
      CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        account_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('receita', 'despesa')),
        value REAL NOT NULL,
        description TEXT,
        date DATE NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE,
        FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE
      )
    `;
    this.db.run(sql);
  }

  // Cria um novo lançamento
  create({ company_id, account_id, category_id, type, value, description, date }) {
    return new Promise((resolve, reject) => {
      const sql = `
        INSERT INTO transactions
        (company_id, account_id, category_id, type, value, description, date)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `;
      this.db.run(sql, [company_id, account_id, category_id, type, value, description, date], function(err) {
        if (err) return reject(err);
        resolve({
          id: this.lastID, company_id, account_id, category_id, type, value, description, date
        });
      });
    });
  }

  // Busca lançamentos por empresa (opcionalmente por conta, categoria, período)
  findByCompany({ company_id, account_id = null, category_id = null, from = null, to = null }) {
    let sql = `SELECT * FROM transactions WHERE company_id = ?`;
    const params = [company_id];
    if (account_id) {
      sql += ` AND account_id = ?`;
      params.push(account_id);
    }
    if (category_id) {
      sql += ` AND category_id = ?`;
      params.push(category_id);
    }
    if (from) {
      sql += ` AND date >= ?`;
      params.push(from);
    }
    if (to) {
      sql += ` AND date <= ?`;
      params.push(to);
    }
    sql += ` ORDER BY date DESC, id DESC`;

    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }
}

module.exports = TransactionModel;